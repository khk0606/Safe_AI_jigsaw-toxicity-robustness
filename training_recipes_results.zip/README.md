# Training Recipes and Results

Project:

```text
Robustness Evaluation of TextCNN Toxicity Detection under Text Perturbations
```

This package contains only the files used for the current presentation flow:

```text
TextCNN clean baseline
TextCNN perturbation-augmented variants
RoBERTa SOTA-style reference evaluation
```

## Research Question

Clean toxicity classification performance may not be enough for moderation. The project asks whether a toxicity detector still identifies toxic comments when users obfuscate toxic words.

Examples:

```text
idiot  -> i d i o t
hate   -> h@te
bad    -> bad!!!
```

## Dataset

Source dataset:

```text
Jigsaw Unintended Bias in Toxicity Classification
```

Mirror used during this project:

```text
Intuit-GenSRF/jigsaw-unintended-bias
```

Binary label rule:

```text
target >= 0.5 -> toxic
target < 0.5  -> non-toxic
```

Balanced split:

| Split | Non-toxic | Toxic | Total |
|---|---:|---:|---:|
| Train | 5,000 | 5,000 | 10,000 |
| Validation | 1,000 | 1,000 | 2,000 |
| Test | 1,000 | 1,000 | 2,000 |

Dataset export:

```text
jigsaw_toxicity_robustness_shareable.zip
```

## Perturbations

The perturbation generator changes the surface form while keeping the original label.

| Perturbation | Example |
|---|---|
| typo | `stupid -> stupdi` |
| char_substitution | `hate -> h@te` |
| spacing | `idiot -> i d i o t` |
| repetition | `bad -> baaad` |
| punctuation_noise | `bad -> bad!!!` |
| combined | `hate -> h @ t e!!!` |

Implementation:

```text
scripts/perturbations.py
```

## Models

### TextCNN

Architecture:

```text
Embedding
-> Conv1D filters with kernel sizes [3, 4, 5]
-> Global max pooling
-> Dropout
-> Linear output
```

Main settings:

| Parameter | Value |
|---|---:|
| max_vocab_size | 30,000 |
| max_len | 128 |
| embedding_dim | 96 |
| filters | 96 |
| dropout | 0.45 |
| epochs | 10 |
| batch_size | 128 |
| learning rate | 0.001 |
| seed | 42 |

TextCNN variants:

| Variant | Training data |
|---|---|
| TextCNN clean | clean train + validation rows |
| TextCNN 25% general augmentation | clean rows + 25% general perturbed rows |
| TextCNN 100% targeted augmentation | clean rows + targeted perturbed copy |

Targeted augmentation types:

```text
spacing
combined
char_substitution
```

### SOTA-style Reference

Public reference model:

```text
unitary/unbiased-toxic-roberta
https://huggingface.co/unitary/unbiased-toxic-roberta
```

This model was not trained by our team. It is used as a strong public RoBERTa-based reference.

## Metrics

| Metric | Meaning | Better Direction |
|---|---|---|
| Clean F1 | F1 score on original clean text | Higher |
| Perturbed F1 | F1 score after perturbation | Higher |
| F1 Drop | Clean F1 - perturbed F1 | Lower |
| ASR | Clean-correct samples that become wrong after perturbation | Lower |
| Toxic Recall Drop | Drop in recall on toxic-only samples | Lower |

## Main Results

### TextCNN Targeted Defense

| Variant | Attack | Clean F1 | Perturbed F1 | F1 Drop | ASR |
|---|---|---:|---:|---:|---:|
| clean baseline | spacing | 0.8075 | 0.7372 | 0.0703 | 0.1001 |
| 100% targeted augmentation | spacing | 0.8315 | 0.8130 | 0.0185 | 0.0356 |
| clean baseline | combined | 0.8075 | 0.7351 | 0.0724 | 0.1255 |
| 100% targeted augmentation | combined | 0.8315 | 0.8012 | 0.0303 | 0.0592 |

### SOTA Reference Comparison

Clean performance on a balanced 1,000-sample Jigsaw test subset:

| Model | Accuracy | Precision | Recall | Clean F1 | AUROC |
|---|---:|---:|---:|---:|---:|
| RoBERTa reference | 0.8530 | 0.9836 | 0.7180 | 0.8301 | 0.9868 |
| TextCNN clean | 0.8110 | 0.8008 | 0.8280 | 0.8142 | 0.9009 |
| TextCNN targeted augmentation | 0.8230 | 0.8088 | 0.8460 | 0.8270 | 0.9040 |

Combined perturbation robustness:

| Model | Clean F1 | Perturbed F1 | F1 Drop | ASR |
|---|---:|---:|---:|---:|
| RoBERTa reference | 0.8301 | 0.7128 | 0.1172 | 0.1079 |
| TextCNN clean | 0.8142 | 0.7277 | 0.0865 | 0.1319 |
| TextCNN targeted augmentation | 0.8270 | 0.7992 | 0.0278 | 0.0571 |

Toxic-only combined evaluation:

| Model | Clean Toxic Recall | Perturbed Toxic Recall | Recall Drop | ASR / Evasion |
|---|---:|---:|---:|---:|
| RoBERTa reference | 0.718 | 0.566 | 0.152 | 10.8% |
| TextCNN clean | 0.828 | 0.676 | 0.152 | 13.2% |
| TextCNN targeted augmentation | 0.846 | 0.804 | 0.042 | 5.7% |

## Included Files

| Path | Description |
|---|---|
| `reports/textcnn_defense_variant_summary.csv` | TextCNN augmentation-ratio and targeted-defense summary |
| `reports/textcnn_defense_variant_summary.md` | Human-readable TextCNN defense summary |
| `reports/sota_vs_textcnn_summary.csv` | Compact RoBERTa vs TextCNN summary |
| `reports/sota_vs_textcnn_metrics.csv` | Full RoBERTa vs TextCNN metric table |
| `reports/sota_vs_textcnn_summary.md` | Human-readable SOTA comparison summary |
| `figures/textcnn_targeted_f1_drop.png` | TextCNN targeted defense F1 drop figure |
| `figures/textcnn_targeted_asr.png` | TextCNN targeted defense ASR figure |
| `figures/sota_clean_performance.png` | Clean performance comparison |
| `figures/sota_vs_textcnn_f1_drop.png` | RoBERTa vs TextCNN robustness drop |
| `figures/sota_vs_textcnn_asr.png` | RoBERTa vs TextCNN ASR |

## Reproduction Commands

Train targeted TextCNN:

```bash
python scripts/train_evaluate_textcnn.py \
  --input-csv data/processed/jigsaw_subset_14k_stratified.csv \
  --output-dir outputs/textcnn_stronger_defense/targeted_100 \
  --train-variants augmented \
  --augmentation-fraction 1.0 \
  --augmentation-perturbations spacing combined char_substitution \
  --epochs 10 \
  --embedding-dim 96 \
  --filters 96 \
  --dropout 0.45 \
  --batch-size 128 \
  --save-models
```

Evaluate RoBERTa reference:

```bash
python scripts/evaluate_sota_toxicity_model.py \
  --input-csv data/processed/jigsaw_subset_14k_stratified.csv \
  --output-dir outputs/sota_unbiased_roberta_1k \
  --model-id unitary/unbiased-toxic-roberta \
  --perturbations char_substitution spacing combined \
  --max-samples 1000 \
  --batch-size 16 \
  --max-length 192
```

## Claim

RoBERTa has the strongest clean performance, but targeted TextCNN is more stable under the controlled text-obfuscation perturbations used in this project. This is a robustness result under a specific threat model, not a claim that TextCNN is generally better than RoBERTa.
