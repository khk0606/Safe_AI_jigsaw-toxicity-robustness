# TextCNN Stronger Defense Variant Summary

## Main Comparison

| variant | perturbation | clean_f1 | perturbed_f1 | robustness_drop_f1 | attack_success_rate | auroc |
| --- | --- | --- | --- | --- | --- | --- |
| clean_baseline | spacing | 0.8075 | 0.7372 | 0.0703 | 0.1001 | 0.8261 |
| clean_baseline | combined | 0.8075 | 0.7351 | 0.0724 | 0.1255 | 0.8270 |
| aug_25_general | spacing | 0.8235 | 0.7770 | 0.0465 | 0.0659 | 0.8788 |
| aug_25_general | combined | 0.8235 | 0.7649 | 0.0586 | 0.0877 | 0.8667 |
| aug_50_targeted | spacing | 0.8231 | 0.7795 | 0.0436 | 0.0650 | 0.8775 |
| aug_50_targeted | combined | 0.8231 | 0.7899 | 0.0333 | 0.0687 | 0.8727 |
| aug_100_targeted | spacing | 0.8315 | 0.8130 | 0.0185 | 0.0356 | 0.8864 |
| aug_100_targeted | combined | 0.8315 | 0.8012 | 0.0303 | 0.0592 | 0.8792 |

## Recommended Final Claim

Use `aug_100_targeted` as the strongest defense result. It keeps clean F1 high while reducing spacing and combined robustness drops the most.

## Key Numbers

- Clean baseline combined F1 drop: 0.0724
- 100% targeted augmentation combined F1 drop: 0.0303
- Clean baseline combined ASR: 0.1255
- 100% targeted augmentation combined ASR: 0.0592
- Clean baseline spacing F1 drop: 0.0703
- 100% targeted augmentation spacing F1 drop: 0.0185
