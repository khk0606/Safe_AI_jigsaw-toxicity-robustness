#!/usr/bin/env python3
"""Evaluate saved TextCNN checkpoints on clean and perturbed Jigsaw comments."""

from __future__ import annotations

import argparse
import json
import re
from collections import Counter
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score, roc_auc_score
from torch import nn
from torch.utils.data import DataLoader, TensorDataset

from perturbations import PERTURBATION_FUNCS, perturb


TOKEN_RE = re.compile(r"[A-Za-z']+|\d+|[^\w\s]")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input-csv", type=Path, default=Path("data/processed/jigsaw_subset_14k_stratified.csv"))
    parser.add_argument("--output-dir", type=Path, default=Path("outputs/textcnn_saved_eval"))
    parser.add_argument(
        "--checkpoints",
        nargs="+",
        required=True,
        help="Checkpoint specs in label=path format.",
    )
    parser.add_argument(
        "--perturbations",
        nargs="+",
        default=["char_substitution", "spacing", "combined"],
        choices=sorted(PERTURBATION_FUNCS),
    )
    parser.add_argument("--max-samples", type=int, default=0)
    parser.add_argument("--batch-size", type=int, default=128)
    parser.add_argument("--seed", type=int, default=42)
    return parser.parse_args()


class TextCNN(nn.Module):
    def __init__(self, vocab_size: int, embedding_dim: int, filters: int, dropout: float) -> None:
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, embedding_dim, padding_idx=0)
        self.convs = nn.ModuleList(
            [nn.Conv1d(embedding_dim, filters, kernel_size=k) for k in [3, 4, 5]]
        )
        self.dropout = nn.Dropout(dropout)
        self.fc = nn.Linear(filters * len(self.convs), 1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.embedding(x).transpose(1, 2)
        pooled = []
        for conv in self.convs:
            h = torch.relu(conv(x))
            pooled.append(torch.max(h, dim=2).values)
        h = torch.cat(pooled, dim=1)
        h = self.dropout(h)
        return self.fc(h).squeeze(1)


def tokenize(text: str) -> list[str]:
    return [token.lower() for token in TOKEN_RE.findall(str(text))]


def encode_texts(texts: list[str], vocab: dict[str, int], max_len: int) -> torch.Tensor:
    encoded = np.zeros((len(texts), max_len), dtype=np.int64)
    unk = vocab["<unk>"]
    for row_idx, text in enumerate(texts):
        ids = [vocab.get(token, unk) for token in tokenize(text)[:max_len]]
        encoded[row_idx, : len(ids)] = ids
    return torch.from_numpy(encoded)


def metrics(y_true: np.ndarray, proba: np.ndarray) -> dict[str, float]:
    pred = (proba >= 0.5).astype(int)
    out = {
        "accuracy": accuracy_score(y_true, pred),
        "precision": precision_score(y_true, pred, zero_division=0),
        "recall": recall_score(y_true, pred, zero_division=0),
        "f1": f1_score(y_true, pred, zero_division=0),
    }
    try:
        out["auroc"] = roc_auc_score(y_true, proba)
    except ValueError:
        out["auroc"] = float("nan")
    return out


def predict(
    model: TextCNN,
    texts: list[str],
    vocab: dict[str, int],
    max_len: int,
    batch_size: int,
    device: torch.device,
) -> np.ndarray:
    model.eval()
    x = encode_texts(texts, vocab, max_len)
    loader = DataLoader(TensorDataset(x), batch_size=batch_size)
    probs = []
    with torch.no_grad():
        for (batch_x,) in loader:
            logits = model(batch_x.to(device))
            probs.append(torch.sigmoid(logits).cpu().numpy())
    return np.concatenate(probs)


def parse_checkpoint_spec(spec: str) -> tuple[str, Path]:
    if "=" not in spec:
        raise ValueError(f"Checkpoint spec must be label=path: {spec}")
    label, path = spec.split("=", 1)
    return label, Path(path)


def load_checkpoint(path: Path, device: torch.device) -> tuple[TextCNN, dict[str, int], int]:
    checkpoint = torch.load(path, map_location=device, weights_only=False)
    args = checkpoint["args"]
    vocab = checkpoint["vocab"]
    model = TextCNN(
        len(vocab),
        int(args["embedding_dim"]),
        int(args["filters"]),
        float(args["dropout"]),
    ).to(device)
    model.load_state_dict(checkpoint["state_dict"])
    return model, vocab, int(args["max_len"])


def evaluate_checkpoint(
    label: str,
    path: Path,
    test_df: pd.DataFrame,
    args: argparse.Namespace,
    device: torch.device,
) -> list[dict[str, object]]:
    model, vocab, max_len = load_checkpoint(path, device)
    y = test_df["label"].astype(int).to_numpy()
    clean_texts = test_df["comment_text"].astype(str).tolist()
    clean_proba = predict(model, clean_texts, vocab, max_len, args.batch_size, device)
    clean_pred = clean_proba >= 0.5
    clean_correct = clean_pred == y
    clean_metrics = metrics(y, clean_proba)

    rows: list[dict[str, object]] = [
        {
            "model": label,
            "test_type": "clean",
            "perturbation": "clean",
            "robustness_drop_f1": 0.0,
            "attack_success_rate": 0.0,
            "confidence_shift": 0.0,
            **clean_metrics,
        }
    ]
    for perturbation_type in args.perturbations:
        perturbed = [
            perturb(text, perturbation_type, seed=args.seed + idx)
            for idx, text in enumerate(clean_texts)
        ]
        pert_proba = predict(model, perturbed, vocab, max_len, args.batch_size, device)
        pert_pred = pert_proba >= 0.5
        pert_metrics = metrics(y, pert_proba)
        clean_correct_count = int(clean_correct.sum())
        attack_success = int((clean_correct & (pert_pred != y)).sum())
        rows.append(
            {
                "model": label,
                "test_type": "perturbed",
                "perturbation": perturbation_type,
                "robustness_drop_f1": clean_metrics["f1"] - pert_metrics["f1"],
                "attack_success_rate": attack_success / clean_correct_count if clean_correct_count else 0.0,
                "confidence_shift": float(np.mean(np.abs(clean_proba - pert_proba))),
                **pert_metrics,
            }
        )
    return rows


def main() -> None:
    args = parse_args()
    reports_dir = args.output_dir / "reports"
    reports_dir.mkdir(parents=True, exist_ok=True)

    df = pd.read_csv(args.input_csv)
    test_df = df[df["split"] == "test"].copy()
    if args.max_samples and args.max_samples < len(test_df):
        test_df = (
            test_df
            .groupby("label", group_keys=False)
            .sample(n=args.max_samples // 2, random_state=args.seed)
            .sample(frac=1, random_state=args.seed)
            .reset_index(drop=True)
        )

    device = torch.device("mps" if torch.backends.mps.is_available() else "cpu")
    print(f"Using device: {device}")
    print(f"Evaluating {len(test_df)} test rows")

    rows = []
    for spec in args.checkpoints:
        label, path = parse_checkpoint_spec(spec)
        print(f"Evaluating {label}: {path}")
        rows.extend(evaluate_checkpoint(label, path, test_df, args, device))

    metrics_df = pd.DataFrame(rows)
    out_path = reports_dir / "robustness_metrics.csv"
    metrics_df.to_csv(out_path, index=False)
    (reports_dir / "run_info.json").write_text(json.dumps(vars(args), indent=2, default=str), encoding="utf-8")
    print(metrics_df.to_string(index=False))
    print(f"Saved TextCNN checkpoint metrics to {out_path}")


if __name__ == "__main__":
    main()
