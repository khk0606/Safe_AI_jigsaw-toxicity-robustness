#!/usr/bin/env python3
"""Prepare a balanced Jigsaw toxicity subset for robustness experiments."""

from __future__ import annotations

import argparse
import os
import json
import random
import sys
from pathlib import Path
from typing import Any


IDENTITY_COLUMNS = [
    "male",
    "female",
    "black",
    "white",
    "muslim",
    "christian",
    "homosexual_gay_or_lesbian",
    "psychiatric_or_mental_illness",
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", choices=["hf_stream", "local_csv"], default="hf_stream")
    parser.add_argument(
        "--hf-dataset",
        default="Intuit-GenSRF/jigsaw-unintended-bias",
        help="Streaming-friendly Hugging Face mirror. Official google dataset needs manual Kaggle files.",
    )
    parser.add_argument("--local-csv", type=Path, default=None)
    parser.add_argument("--output-csv", type=Path, default=Path("data/processed/jigsaw_subset.csv"))
    parser.add_argument("--stats-json", type=Path, default=Path("outputs/reports/dataset_stats.json"))
    parser.add_argument("--train-size", type=int, default=10_000)
    parser.add_argument("--val-size", type=int, default=2_000)
    parser.add_argument("--test-size", type=int, default=2_000)
    parser.add_argument("--threshold", type=float, default=0.5)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--shuffle-buffer", type=int, default=20_000)
    return parser.parse_args()


def normalize_row(row: dict[str, Any], threshold: float) -> dict[str, Any] | None:
    text = row.get("comment_text")
    if text is None:
        text = row.get("text")
    if text is None or not str(text).strip():
        return None

    target = row.get("target")
    if target is None:
        target = row.get("toxicity")

    if target is not None:
        try:
            label = int(float(target) >= threshold)
            target_value = float(target)
        except (TypeError, ValueError):
            return None
    elif "labels" in row:
        labels = row.get("labels") or []
        labels = [str(label).lower() for label in labels]
        label = int("toxic" in labels)
        target_value = float(label)
    elif "toxic" in row:
        label = int(row["toxic"])
        target_value = float(label)
    else:
        return None

    out = {
        "comment_text": str(text),
        "target": target_value,
        "label": label,
    }
    for col in IDENTITY_COLUMNS:
        out[col] = row.get(col)
    return out


def collect_from_hf(args: argparse.Namespace, total_needed: int) -> list[dict[str, Any]]:
    from datasets import load_dataset

    dataset = load_dataset(args.hf_dataset, split="train", streaming=True)
    dataset = dataset.shuffle(seed=args.seed, buffer_size=args.shuffle_buffer)

    per_class_needed = total_needed // 2
    counts = {0: 0, 1: 0}
    rows: list[dict[str, Any]] = []

    for row in dataset:
        item = normalize_row(row, args.threshold)
        if item is None:
            continue
        label = int(item["label"])
        if counts[label] >= per_class_needed:
            continue
        rows.append(item)
        counts[label] += 1
        if counts[0] >= per_class_needed and counts[1] >= per_class_needed:
            break

    if counts[0] < per_class_needed or counts[1] < per_class_needed:
        raise RuntimeError(f"Could not collect enough balanced rows: {counts}")

    return rows


def collect_from_local_csv(args: argparse.Namespace, total_needed: int) -> list[dict[str, Any]]:
    import pandas as pd

    if args.local_csv is None:
        raise ValueError("--local-csv is required when --source local_csv")

    df = pd.read_csv(args.local_csv)
    rows = []
    for row in df.to_dict(orient="records"):
        item = normalize_row(row, args.threshold)
        if item is not None:
            rows.append(item)

    out_df = pd.DataFrame(rows)
    toxic = out_df[out_df["label"] == 1]
    non_toxic = out_df[out_df["label"] == 0]
    per_class_needed = total_needed // 2
    if len(toxic) < per_class_needed or len(non_toxic) < per_class_needed:
        raise RuntimeError(
            f"Not enough rows for balanced subset. toxic={len(toxic)}, non_toxic={len(non_toxic)}"
        )
    sampled = pd.concat(
        [
            toxic.sample(per_class_needed, random_state=args.seed),
            non_toxic.sample(per_class_needed, random_state=args.seed),
        ],
        ignore_index=True,
    ).sample(frac=1.0, random_state=args.seed)
    return sampled.to_dict(orient="records")


def assign_splits(
    rows: list[dict[str, Any]],
    train_size: int,
    val_size: int,
    test_size: int,
    seed: int,
) -> list[dict[str, Any]]:
    for size_name, size in [("train", train_size), ("val", val_size), ("test", test_size)]:
        if size % 2 != 0:
            raise ValueError(f"{size_name}_size must be even for balanced stratified splits.")

    rng = random.Random(seed)
    by_label = {
        0: [row for row in rows if int(row["label"]) == 0],
        1: [row for row in rows if int(row["label"]) == 1],
    }
    rng.shuffle(by_label[0])
    rng.shuffle(by_label[1])

    split_plan = [("train", train_size), ("val", val_size), ("test", test_size)]
    assigned: list[dict[str, Any]] = []
    offsets = {0: 0, 1: 0}
    for split_name, split_size in split_plan:
        per_class = split_size // 2
        for label in [0, 1]:
            start = offsets[label]
            end = start + per_class
            chunk = by_label[label][start:end]
            if len(chunk) != per_class:
                raise RuntimeError(f"Not enough label={label} rows for {split_name} split.")
            for row in chunk:
                copied = dict(row)
                copied["split"] = split_name
                assigned.append(copied)
            offsets[label] = end

    rng.shuffle(assigned)
    return assigned


def main() -> None:
    import pandas as pd

    args = parse_args()
    total_needed = args.train_size + args.val_size + args.test_size
    if total_needed % 2 != 0:
        raise ValueError("Total size must be even for balanced sampling.")

    if args.source == "hf_stream":
        rows = collect_from_hf(args, total_needed)
    else:
        rows = collect_from_local_csv(args, total_needed)

    rows = assign_splits(rows, args.train_size, args.val_size, args.test_size, args.seed)
    df = pd.DataFrame(rows)

    args.output_csv.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(args.output_csv, index=False)

    stats = {
        "source": args.source,
        "hf_dataset": args.hf_dataset if args.source == "hf_stream" else None,
        "local_csv": str(args.local_csv) if args.local_csv else None,
        "output_csv": str(args.output_csv),
        "rows": int(len(df)),
        "split_counts": df["split"].value_counts().to_dict(),
        "label_counts": df["label"].value_counts().sort_index().to_dict(),
        "split_label_counts": {
            split: df[df["split"] == split]["label"].value_counts().sort_index().to_dict()
            for split in ["train", "val", "test"]
        },
        "threshold": args.threshold,
    }
    args.stats_json.parent.mkdir(parents=True, exist_ok=True)
    args.stats_json.write_text(json.dumps(stats, indent=2), encoding="utf-8")
    print(json.dumps(stats, indent=2))
    sys.stdout.flush()

    # The Hugging Face streaming stack can leave background network resources open
    # after all rows are written. This script is a one-shot data preparation command,
    # so force a clean process exit once the files are safely flushed.
    if args.source == "hf_stream":
        os._exit(0)


if __name__ == "__main__":
    main()
