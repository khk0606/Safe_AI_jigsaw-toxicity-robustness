#!/usr/bin/env python3
"""Create a compact SOTA-vs-project-model comparison report."""

from __future__ import annotations

import os
from pathlib import Path

import pandas as pd


SOTA_CSV = Path("outputs/sota_unbiased_roberta_1k/reports/robustness_metrics.csv")
TEXTCNN_CSV = Path("outputs/textcnn_sota_comparison_1k/reports/robustness_metrics.csv")
OUT_DIR = Path("outputs/sota_comparison_1k")


def markdown_table(df: pd.DataFrame) -> str:
    headers = list(df.columns)
    lines = [
        "| " + " | ".join(headers) + " |",
        "| " + " | ".join(["---"] * len(headers)) + " |",
    ]
    for _, row in df.iterrows():
        values = []
        for header in headers:
            value = row[header]
            if isinstance(value, float):
                values.append(f"{value:.4f}")
            else:
                values.append(str(value))
        lines.append("| " + " | ".join(values) + " |")
    return "\n".join(lines)


def main() -> None:
    os.environ.setdefault("MPLCONFIGDIR", str(Path("outputs/mpl_cache").resolve()))
    os.environ.setdefault("MPLBACKEND", "Agg")
    Path(os.environ["MPLCONFIGDIR"]).mkdir(parents=True, exist_ok=True)

    import matplotlib.pyplot as plt

    reports_dir = OUT_DIR / "reports"
    figures_dir = OUT_DIR / "figures"
    reports_dir.mkdir(parents=True, exist_ok=True)
    figures_dir.mkdir(parents=True, exist_ok=True)

    sota = pd.read_csv(SOTA_CSV)
    textcnn = pd.read_csv(TEXTCNN_CSV)
    sota["model"] = "sota_unbiased_roberta"
    combined = pd.concat([sota, textcnn], ignore_index=True)
    combined.to_csv(reports_dir / "sota_vs_textcnn_metrics.csv", index=False)

    clean_f1 = combined[combined["test_type"] == "clean"].set_index("model")["f1"].to_dict()
    perturbed = combined[combined["test_type"] == "perturbed"].copy()
    perturbed["clean_f1"] = perturbed["model"].map(clean_f1)
    summary = perturbed[
        [
            "model",
            "perturbation",
            "clean_f1",
            "f1",
            "robustness_drop_f1",
            "attack_success_rate",
            "auroc",
        ]
    ].rename(columns={"f1": "perturbed_f1"})
    summary.to_csv(reports_dir / "sota_vs_textcnn_summary.csv", index=False)

    clean_summary = (
        combined[combined["test_type"] == "clean"][
            ["model", "accuracy", "precision", "recall", "f1", "auroc"]
        ]
        .rename(columns={"f1": "clean_f1"})
        .reset_index(drop=True)
    )
    clean_summary.to_csv(reports_dir / "sota_vs_textcnn_clean_summary.csv", index=False)

    model_order = ["sota_unbiased_roberta", "textcnn_clean", "textcnn_aug_100_targeted"]
    for metric, ylabel, filename in [
        ("robustness_drop_f1", "Clean F1 - Perturbed F1", "sota_vs_textcnn_f1_drop.png"),
        ("attack_success_rate", "Attack Success Rate", "sota_vs_textcnn_asr.png"),
        ("perturbed_f1", "Perturbed F1", "sota_vs_textcnn_perturbed_f1.png"),
    ]:
        pivot = summary.pivot(index="model", columns="perturbation", values=metric).loc[model_order]
        ax = pivot.plot(kind="bar", figsize=(10, 5))
        ax.set_title(f"SOTA vs TextCNN: {ylabel}")
        ax.set_xlabel("Model")
        ax.set_ylabel(ylabel)
        ax.legend(title="Perturbation")
        plt.xticks(rotation=20, ha="right")
        plt.tight_layout()
        plt.savefig(figures_dir / filename, dpi=180)
        plt.close()

    md = "\n".join(
        [
            "# SOTA vs Project Model Comparison",
            "",
            "## Setup",
            "",
            "- SOTA reference: `unitary/unbiased-toxic-roberta`",
            "- Project models: `textcnn_clean`, `textcnn_aug_100_targeted`",
            "- Evaluation subset: balanced 1,000 samples from the Jigsaw test split",
            "- Perturbations: `char_substitution`, `spacing`, `combined`",
            "- Decision threshold: toxicity score >= 0.5",
            "",
            "## Clean Performance",
            "",
            markdown_table(clean_summary),
            "",
            "## Robustness Summary",
            "",
            markdown_table(summary),
            "",
            "## Key Takeaway",
            "",
            (
                "The public RoBERTa-based SOTA reference has strong clean performance, "
                "but it is still vulnerable to the exact obfuscation-style perturbations "
                "used in this project. The targeted augmented TextCNN is not a better "
                "general SOTA model, but it is more robust on this controlled perturbation "
                "test."
            ),
            "",
            "Most important comparison:",
            "",
            "- SOTA combined F1 drop: 0.1172",
            "- TextCNN clean combined F1 drop: 0.0865",
            "- TextCNN targeted augmentation combined F1 drop: 0.0278",
            "- SOTA combined ASR: 0.1079",
            "- TextCNN targeted augmentation combined ASR: 0.0571",
            "",
            "Use this wording in the final report:",
            "",
            (
                "> Compared with a public RoBERTa-based toxicity classifier, the targeted "
                "augmentation TextCNN achieved lower robustness drop and lower attack success "
                "rate under spacing and combined obfuscation attacks on the same balanced Jigsaw "
                "test subset. This suggests that robustness-targeted training can outperform "
                "a stronger clean classifier on the specific moderation-evasion threat model."
            ),
            "",
            "## Caveat",
            "",
            (
                "This is not an official Kaggle leaderboard comparison. The SOTA model was not "
                "fine-tuned on the exact augmented data used here, and the evaluation uses a "
                "balanced 1k subset plus custom perturbation attacks. Therefore the fair claim is "
                "about robustness under this threat model, not overall SOTA accuracy."
            ),
            "",
        ]
    )
    (reports_dir / "sota_vs_textcnn_summary.md").write_text(md, encoding="utf-8")

    print(f"Saved comparison reports to {reports_dir}")
    print(f"Saved comparison figures to {figures_dir}")


if __name__ == "__main__":
    main()
